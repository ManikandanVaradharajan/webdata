#Installing IIS Roles & Setup website
import-module servermanager
add-windowsfeature web-server -includeallsubfeature
add-windowsfeature Web-Asp-Net45
add-windowsfeature NET-Framework-Features

#Clean-up default HTM items after installing IIS roles
Remove-Item C:\inetpub\wwwroot\* -Recurse -Force
Start-Sleep -Seconds 20

#Moving custom site files from TEMP directory to IIS Web root
Invoke-webrequest 'https://github.com/ManikandanVaradharajan/webdata/archive/refs/heads/main.zip' -OutFile ./webdata.zip
Expand-Archive ".\webdata.zip" "C:\Windows\Temp\webdata\"
Expand-Archive "C:\Windows\Temp\webdata\webdata-main\webdata.zip" "C:\Windows\Temp\webdata\webdata-main"
Copy-Item -Path "C:\Windows\Temp\webdata\webdata-main\webdata\*" -Destination "C:\inetpub\wwwroot" -Recurse
Start-Sleep -Seconds 20

#Setting up test website
Import-Module WebAdministration -Force
New-WebSite -Name "Testsite" -port 8080 -PhysicalPath "%SystemDrive%\inetpub\wwwroot" -ApplicationPool "DefaultAppPool" -force
Start-Website -Name "Testsite"

#set windows defender rule to allow port 8080
netsh advfirewall firewall add rule name="Open Port 8080" dir=in action=allow protocol=TCP localport=8080

Start-Sleep -Seconds 60
Remove-Item 'C:\Windows\Temp\webdata' -Recurse -Force


